package com.alibalci.isgmobil.isg.isgbackend.exception;

public class BadRequestException
        extends BusinessException {

    public BadRequestException(
            String code,
            String message) {
        super(code, message);
    }
}